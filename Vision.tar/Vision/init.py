#!/usr/bin/python

import os, sys,time
from subprocess import PIPE, Popen, call

date = Popen('date +"%m-%d-%y"', shell = True, stdout = PIPE).stdout.read().split('\n')[0]
if not os.path.exists('bin/data/'+str(date)):
    os.system('python bin/dtfrm.py')

os.system('xdotool key F11; clear')

platform = Popen('uname -a', shell = True, stdout = PIPE).stdout.read()

if 'Ubuntu' or 'ubuntu' in platform:
    os.system("sudo su -c 'python main/MainWindow.py'")

elif 'kali' or 'Kali' in platform:
    os.system("sudo 'python main/MainWindow.py'")

else:
    os.system('su python main/MainWindow.py')
