import socket, os, sys, time
import hashlib

def connect():
    s= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", port))
    s.listen(1)
    os.system('clear')
    print '\n\n\n\t    [+]\033[94m Listening For Incoming...\033[0;0m'
    conn, addr=s.accept()
    print '\t    [+] We got a connection from:', addr
    
    product = 'abc123def456ghi7:key'
    keypro = product[:-4]
    obj = hashlib.sha256(keypro)
    key = obj.hexdigest()
#    conn.send(product)

    while True:

        packet = conn.recv(1024)

        if packet.endswith(':key'):
            inc_key = packet[:-4]
            print '\t    [!]\033[92m Received Key Input From The Victim!\033[0;0m\n'
            hash_obj = hashlib.sha256(inc_key)
            hex_dig = hash_obj.hexdigest()

            if hex_dig == key:
                print '\t    [+] \033[91mSUCCESS: \033[0;0mKey Match!'
                time.sleep(1)
                conn.send('dec')
            else:
                print "\t   \033[91m [X] WRONG Key\033[0;0m"
                conn.send('Wrong Key!')
        
        elif packet.endswith('done'):
            conn.send('Thanks For The Gift :D')
            time.sleep(2)
            break
        
        else:
            print packet

    conn.close()
port = 4445

connect()
