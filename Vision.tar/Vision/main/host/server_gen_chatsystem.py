import socket
import sys
from threading import Thread
import os
import signal

def connect():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 10)
    s.bind (('0.0.0.0', port))
    os.system('clear')
    sys.stdout.write("\n             Connection Status    :    ")
    s.listen(1)
    conn, addr = s.accept()
    sys.stdout.write("\033[92mCONNETED\033[0;0m\n")
    print "\n            \033[1m\033[36mCHAT SYSTEM\033[0;0m\n"

    while True:
        outgoing = raw_input("             \033[92mSend        \033[0;0m: ")
        conn.send(outgoing)
        incoming = conn.recv(1024)

        if outgoing == 'bye':
            os.kill(os.getppid(), signal.SIGHUP)

        if incoming == 'bye':
            os.kill(os.getppid(), signal.SIGHUP)

        print "            \033[91mReceived    \033[0;0m:", incoming


