#!usr/bin/python

import socket
import sys
import os
import time
import subprocess
from scapy.all import *
from Queue import Queue
from threading import Thread
from subprocess import Popen, call, PIPE

date = Popen('date +"%m-%d-%y"', shell = True, stdout = PIPE).stdout.read().split('\n')[0]

c_time = Popen("date | awk '{print $4}'", shell = True, stdout = PIPE).stdout.read().split('\n')[0]

datare = open('bin/data/'+str(date)+'/ban_grb/Ban_grb_'+str(c_time)+'.log','a')


try:
    sys.stdout.write("            [*]\033[94m Internet Connection Status        \033[0:0m:    ")
    sys.stdout.flush()
    if socket.gethostbyname('www.google.com'):
        sys.stdout.write("\033[92mCONNECTED\033[0;0m\n")

except:
    sys.stdout.write("\033[91mNOT CONNECTED\033[0;0m\n")
    sys.stdout.write("            Please Check Your Internet Connection!\n\n")
    
    sys.exit(0)

def Banner_Grab():
    try:
        try:
            inp_url = raw_input ("\n\n\n            Enter URL or IP: ")
            ip_addr = socket.gethostbyname (inp_url)
            port = int(raw_input("            Enter Port To Scan: "))
            datare.write('URL/IP: '+str(inp_url)+'\nPORT: '+str(port)+'\n\n')
        except:
            os.system('clear')
            sys.stdout.write("\n\n\033[91m            INVALID\033[0;0m Input! Try Again!")
            Banner_Grab()
        try:
            mysocket = socket.socket()                            
            mysocket.connect((ip_addr, port)) 
        except:
            os.system('clear')
            print "    \033[91m        ERROR\033[0;0m Connecting The Target!"
            datare.close()
            os.remove('bin/data/'+str(date)+'/ntwrk_sc/Ntwrk_sc_'+str(c_time)+'.log')
            Options()

        print "\n\033[94m            [*] Grabbing Banner... \033[0;0m\n" 
        
        try:
            data= mysocket.recv(2048).split('\n')                                               
            sys.stdout.write("         \033[1m   Banner On Port "+str(port)+':\033[0;0m\n\n'+'            '+str(data))
            
            datare.write(str(data))
            datare.close()
            try:
                mysocket.close()
                i = input("\n\n            Press ENTER To Get Back To The Menu...")
            except:
                datare.close()
                os.remove('bin/data/'+str(date)+'/ntwrk_sc/Ntwrk_sc_'+str(c_time)+'.log')
                Options()
        except:
            os.system('clear')
            print "    \033[91m        ERROR\033[0;0m Grabbing Banner!"
            datare.close()
            os.remove('bin/data/'+str(date)+'/ntwrk_sc/Ntwrk_sc_'+str(c_time)+'.log')
            Options()
    except:
        os.system('clear')
        print "\n    \033[91m        ERROR\033[0;0m Retriving Banner!"
        datare.close()
        os.remove('bin/data/'+str(date)+'/ntwrk_sc/Ntwrk_sc_'+str(c_time)+'.log')
        Options()


def Options():
    
    os.system('clear')
    print "\n\n\n\033[36m\033[1m            BANNER-GRABBER\033[0;0m\n"

    print "\n    \033[1m\033[36m        Enter Choice:\033[0;0m\n\n            1) List Open Ports On Target  \n            2) Grab Banner Of a Target  \n            3) \033[91mEXIT\033[0;0m"


    try:
        inp=int(raw_input("\n            Choice> "))
    
        if inp==1:
            subprocess.call('python main/Multithreaded_Portscanner.py',shell=True)
            Options()

        elif inp==2:
            os.system('clear')
            Banner_Grab()

        elif inp==3:
            sys.exit
        else:
            os.system('clear')
            print "\n\033[91m            INVALID\033[0;0m Input! Please Try Again!"
            Options()
    except:
        os.system('clear')
        print "\n\033[91m            INVALID\033[0;0m Input! Please Try Again!"
        Options()


Options()
