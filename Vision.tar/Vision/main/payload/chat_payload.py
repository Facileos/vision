from subprocess import Popen, PIPE, call
import os

i = Popen('hostname -I', shell = True, stdout = PIPE)
inp = i.stdout.read().split('\n')[0].split(' ')[0]

port_inp = int(input('\n\n            Enter The Port Number To Listen On: '))

os.system('cp main/clients/client_gen_chatsystem.py main/clients/chatclient.py')
os.system('cp main/host/server_gen_chatsystem.py main/host/server_chatsystem.py')

f= open('main/clients/chatclient.py','a')
f1 = open('main/host/server_chatsystem.py', 'a')
f.write("ip_addr= '"+str(inp)+"'"+'\nport='+str(port_inp)+'\n\n'+'connect()')
f1.write('\nport='+str(port_inp)+'\n\n'+'connect()')
f1.close()
f.close()

os.system('cp main/clients/chatclient.py /var/www/html; service apache2 restart; rm -rf main/clients/chatclient.py')
