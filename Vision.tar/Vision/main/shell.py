from subprocess import Popen, PIPE, call
import os, sys, signal

os.system('clear')

print "\n\n\n\033[1m            \033[91mTERMINAL\033[0;0m\n\n\033[1m            Unsupported:\n\n            \033[94m'[TAB]' '[UP]' '[DOWN]' '[LEFT]' '[RIGHT]' '[cd< >]'\033[0;0m"


user = Popen("who | awk '{print $1}'", shell = True, stdout=PIPE).stdout.read().split('\n')[0]
uname = Popen('uname', shell = True, stdout = PIPE).stdout.read().split('\n')[0]
os.chdir('/home/'+str(user))
present = Popen('pwd', shell = True, stdout = PIPE).stdout.read().split('\n')[0]

def console():
    present = Popen('pwd', shell = True, stdout = PIPE).stdout.read().split('\n')[0]

    while True:
        try:
            inp = raw_input('\n\n\033[1m\033[92m            '+str(user)+'\033[0;0m\033[1m'+':\033[94m'+str(present)+"\033[0;0m$ ")
            if inp == 'exit':
                os.kill(os.getpid(), signal.SIGKILL)

            re = inp.split(' ')
    
            if re[0] == 'cd':
                if len(re)>1 and re[1].startswith('/'):
                    os.chdir(re[1].split('\n')[0])
                    console()
                elif len(re)>1 and not re[1].startswith('/'):
                    os.chdir(str(present)+'/'+re[1].split('\n')[0])
                    console()
                else:
                    os.chdir('/home/'+str(user))
                    console()

            length = len((Popen(inp, shell = True, stdout = PIPE).stdout.read()).split('\n'))
            sys.stdout.write('            ')
            sys.stdout.flush()

            for i in range(0,length):
                if len(((Popen(inp, shell = True, stdout = PIPE, stderr = PIPE).stdout.read()).split('\n')[i]))>20:
                    sys.stdout.write(((Popen(inp, shell = True, stdout = PIPE).stdout.read()).split('\n')[i])+"\n            ")
                    sys.stdout.flush()
                else:
                    if i == 13:
                        sys.stdout.write('\n            ')
                        sys.stdout.flush()

                    sys.stdout.write(((Popen(inp, shell = True, stdout = PIPE).stdout.read()).split('\n')[i])+" ")
                    sys.stdout.flush()
            sys.stdout.write('\n')

        except Exception:
            print "\033[91m            Enter Again!"
console()        
