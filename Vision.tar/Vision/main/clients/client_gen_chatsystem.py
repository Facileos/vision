import socket
import sys
import os, signal
import subprocess
from subprocess import PIPE, Popen

def connect():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    os.system('clear')
    sys.stdout.write("\nConnection Status    :    ")

    command = "hostname -I"

    p = subprocess.Popen(command, shell = True, stdout=PIPE)
    ip = p.stdout.read()

    try:
        s.connect((ip_addr, port))
        sys.stdout.write("\033[92mCONNETED\033[0;0m\n")

    except:
        sys.stdout.write("\033[91mNOT CONNETED\033[0;0m\n")

    print "\n\033[1m\033[36mCHAT SYSTEM\033[0;0m\n"

    while True:
        incoming = s.recv(1024)
        print "\033[91mReceived     \033[0;0m:", incoming
        outgoing = raw_input("\033[92mSend         \033[0;0m: ")
        s.send(outgoing)
    
        if outgoing == 'bye':
            os.kill(os.getppid(), signal.SIGHUP)
    
        if incoming == 'bye':
            os.kill(os.getppid(), signal.SIGHUP)


